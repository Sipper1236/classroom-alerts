(() => {
  // Capture the actually loaded scripts; getManifest() may already report a newer install.
  const build=globalThis.ClassroomBuild,core=globalThis.ClassroomCore,extractor=globalThis.ClassroomExtractor;
  if(globalThis.classroomAlertsLoaded)return;
  globalThis.classroomAlertsLoaded=true;
  browser.runtime.onMessage.addListener((message,sender)=>{
    if(sender.id!==browser.runtime.id || !message || message.type!=='collect')return undefined;
    return (async()=>{
      const handshake={protocol:build?.protocol,buildId:build?.id,contentVersion:build?.version,
        coreBuild:core?.buildId,extractorBuild:extractor?.buildId,requestId:message.requestId};
      if(!build||message.protocol!==build.protocol||message.expectedBuild!==build.id||core?.buildId!==build.id||extractor?.buildId!==build.id||typeof message.requestId!=='string'||!message.requestId||message.requestId.length>100){
        return {error:'SCRIPT_VERSION_MISMATCH',handshake};
      }
      let truncated=false;
      if(message.expand){
        // Only scroll this read-only page. Never click arbitrary controls or submission buttons.
        const oldY=scrollY;let prior=0,stable=0;
        for(let step=0;step<6;step++){
          window.scrollTo(0,document.documentElement.scrollHeight);
          await new Promise(resolve=>setTimeout(resolve,450));
          const count=document.querySelectorAll('a[href]').length;
          stable=count===prior?stable+1:0;prior=count;
          if(stable>=2)break;
          if(step===5)truncated=true;
        }
        window.scrollTo(0,oldY);
      }
      const result=extractor.extract(document,location.href,message.settings);
      result.report.truncated ||= truncated;
      result.report.version=build.version;
      result.handshake=handshake;
      const link=[...document.querySelectorAll('a[href]')].find(a=>a.textContent.trim()==='Classwork' && core.identity(a.href)?.courseId===core.identity(location.href)?.courseId);
      result.classworkURL=link?.href || null;
      return result;
    })();
  });
})();
