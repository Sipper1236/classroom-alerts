// Generated release stamp; derived from reviewed runtime assets.
(() => {
  const build=Object.freeze({"version":"0.6.0","id":"0.6.0-3e54ae0e9a234ad3ebef","protocol":1});
  globalThis.ClassroomBuild=build;
  if(typeof module!=='undefined')module.exports=build;
})();
