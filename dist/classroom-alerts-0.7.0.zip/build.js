// Generated release stamp; derived from reviewed runtime assets.
(() => {
  const build=Object.freeze({"version":"0.7.0","id":"0.7.0-c320f8110f30062420cd","protocol":1});
  globalThis.ClassroomBuild=build;
  if(typeof module!=='undefined')module.exports=build;
})();
