// Generated release stamp; derived from reviewed runtime assets.
(() => {
  const build=Object.freeze({"version":"0.8.0","id":"0.8.0-cc2b75ee23cd060a879e","protocol":1});
  globalThis.ClassroomBuild=build;
  if(typeof module!=='undefined')module.exports=build;
})();
